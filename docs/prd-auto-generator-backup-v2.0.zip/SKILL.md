---
name: prd-auto-generator
description: "基于项目功能大纲、源码和需求文档规范，自动生成完整的产品需求文档(PRD)。支持Mermaid流程图、业务规则定义、一致性检查等功能。"
risk: low
source: project
date_added: "2026-04-04"
version: "2.0"
---

# PRD文档自动生成技能

基于项目功能大纲、源码分析和需求文档规范，自动化生成标准化产品需求文档的专业技能。

## 使用场景

- 需要为新项目或新功能模块创建PRD文档
- 已有功能大纲和源码，需要规范化输出需求文档
- 需要确保PRD文档与功能大纲、实际代码保持一致

## 输入参数

| 参数名称 | 参数说明 | 示例值 |
|----------|----------|--------|
| 功能大纲路径 | 项目功能结构大纲文件路径 | feature-outline.md |
| 规范文档路径 | 需求文档编写规范模板路径 | references/prd-template-specification.md |
| 源码目录 | 项目源码根目录 | src/ |
| 输出路径 | 生成的PRD文档保存路径，需包含版本号 | PRD-{项目名}-V1.0.md |

---

## 执行流程概览

```mermaid
flowchart TD
    A[开始] --> B{功能大纲是否存在}
    B -->|否| C[Phase0: 生成功能大纲草案]
    C --> D[用户确认]
    B -->|是| E[Phase1: 信息收集]
    D -->|确认| E
    E --> F[Phase2: 模块分析]
    F --> G[Phase2.5: 分计划执行]
    G --> H[Phase3: 文档生成]
    H --> I[Phase4: 一致性检查]
    I --> J[输出PRD文档]
    J --> K[结束]
```

### 详细执行阶段

| 阶段 | 说明 | 参考文档 |
|------|------|----------|
| Phase 0 | 功能大纲确认：分析源码生成功能大纲草案 | [prompts/phase0-outline-confirm.md](prompts/phase0-outline-confirm.md) |
| Phase 1 | 信息收集：读取功能大纲、解析规范、扫描源码 | [prompts/phase1-info-collect.md](prompts/phase1-info-collect.md) |
| Phase 2 | 模块分析：判断模块是否需要拆分 | [prompts/phase2-module-analysis.md](prompts/phase2-module-analysis.md) |
| Phase 2.5 | 分计划执行：按小节数量计算计划数，分步生成 | [prompts/phase2.5-plan-execution.md](prompts/phase2.5-plan-execution.md) |
| Phase 3 | 文档生成：按标准章节结构生成内容 | [prompts/phase3-doc-generation.md](prompts/phase3-doc-generation.md) |
| Phase 4 | 一致性检查：对比大纲、校验规则 | [prompts/phase4-consistency-check.md](prompts/phase4-consistency-check.md) |

---

## 核心规则索引

| 规则类型 | 说明 | 参考文档 |
|----------|------|----------|
| 流程图编写 | 绘制场景判定、节点命名、与业务规则映射 | [rules/flowchart-rules.md](rules/flowchart-rules.md) |
| 源码分析 | HTML/JS/TypeScript项目分析方法 | [rules/sourcecode-analysis.md](rules/sourcecode-analysis.md) |
| 命名规范 | 字段标识snake_case、标题编号格式 | [rules/naming-conventions.md](rules/naming-conventions.md) |
| 章节生成 | 按需生成判断表、典型场景示例 | [rules/chapter-generation.md](rules/chapter-generation.md) |

---

## 输出模板索引

| 模板类型 | 说明 | 参考文档 |
|----------|------|----------|
| 文档头部 | 前置章节结构 | [templates/prd-header.md](templates/prd-header.md) |
| 页面章节 | 六级子项完整模板 | [templates/prd-page-section.md](templates/prd-page-section.md) |
| 文档尾部 | 非功能需求、附录、版本记录 | [templates/prd-footer.md](templates/prd-footer.md) |
| 业务规则表 | 规则编号命名、表格格式 | [templates/business-rule-table.md](templates/business-rule-table.md) |

---

## 校验工具索引

| 工具类型 | 说明 | 参考文档 |
|----------|------|----------|
| 质量检查清单 | 6大类检查项 | [validators/quality-checklist.md](validators/quality-checklist.md) |
| 常见错误对照 | 15种错误类型 | [validators/common-errors.md](validators/common-errors.md) |
| 格式校验脚本 | 自动校验PRD格式 | [scripts/validate-prd.sh](scripts/validate-prd.sh) |
| 一致性校验脚本 | 校验与大纲一致性 | [scripts/check-consistency.sh](scripts/check-consistency.sh) |

---

## 参考文档

| 文档名称 | 说明 |
|----------|------|
| [references/prd-template-specification.md](references/prd-template-specification.md) | PRD文档章节结构规范 |
| [references/example-feature-outline.md](references/example-feature-outline.md) | 功能大纲格式示例 |
| [references/example-prd-output-v3.md](references/example-prd-output-v3.md) | V3.0完整PRD示例 |

---

## 测试用例

| 用例名称 | 测试场景 |
|----------|----------|
| [test-cases/simple-component.json](test-cases/simple-component.json) | 简单配置组件 |
| [test-cases/complex-flow.json](test-cases/complex-flow.json) | 复杂操作流程 |
| [test-cases/state-machine.json](test-cases/state-machine.json) | 状态机设计 |

---

## 版本记录

| 版本号 | 更新日期 | 更新内容 |
|--------|----------|----------|
| V2.0 | 2026-04-04 | 模块化重构：拆分prompts/、rules/、templates/、validators/目录 |
| V1.6 | 2026-04-04 | 新增分计划执行机制、章节按需生成规则 |
| V1.5 | 2026-04-04 | 新增Phase0功能大纲确认流程 |
| V1.0 | 2026-03-18 | 初始版本 |